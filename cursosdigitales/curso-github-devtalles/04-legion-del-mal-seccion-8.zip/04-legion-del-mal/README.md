![Estático](https://img.shields.io/badge/Legion--del--Mal-Última--Versión-blue)

![Con logo](https://img.shields.io/badge/Git-2.45-F05032?style=for-the-badge&logo=git&logoColor=white)

![Workflow](https://img.shields.io/github/actions/workflow/status/klerithx2/legion-del-mal/ci.yml)
![Release](https://img.shields.io/github/v/release/klerithx2/legion-del-mal)
![Issues](https://img.shields.io/github/issues/klerithx2/legion-del-mal)
![Último commit](https://img.shields.io/github/last-commit/klerithx2/legion-del-mal)
![Licencia](https://img.shields.io/github/license/klerithx2/legion-del-mal?cacheSeconds=60)

# 🦹‍♂️ La Legión del Mal

> _"El mundo no se conquista con fuerza bruta, se conquista con un buen plan y control de versiones."_
> — Lex Luthor, fundador

## ¿Quiénes somos? - Desde remoto y local

Somos la alianza definitiva de supervillanos. Mientras los héroes se dividen entre Metrópolis, Gotham y Nueva York, nosotros hemos hecho lo que ellos jamás lograron: unirnos. DC, Marvel, no importa el universo — aquí solo importa el objetivo.

## Estructura de la organización!!

```
📁 planes/          → Operaciones aprobadas por el Consejo
📁 miembros/        → Fichas de cada miembro activo
📁 guaridas/        → Ubicaciones y estado de nuestras bases
📁 inteligencia/    → Expedientes de los héroes enemigos
📄 misiones.yaml    → Estado global de todas las misiones
📄 README.md      → Documentación principal del repositorio
📄 nuevas-misiones.yaml    → Estado global de las nuevas misiones
```

## El Consejo de Villanos!!

| Rango                     | Miembro    | Rol                                                     |
| ------------------------- | ---------- | ------------------------------------------------------- |
| 🥇 Líder supremo          | Lex Luthor | Fundador, financista y estratega principal              |
| 🥈 Segundo al mando       | Magneto    | Estratega militar y reclutamiento de mutantes           |
| 🥉 Jefa de infiltración   | Mystique   | Espionaje, identidades falsas y operaciones encubiertas |
| ⚙️ Director de tecnología | Brainiac   | Sistemas, armamento y recopilación de datos             |

## Miembros activos (campo)

- **Joker** — Operaciones de distracción y caos
- **Doctor Doom** — Armamento avanzado y magia
- **Loki** — Engaño, ilusiones y diplomacia hostil
- **Catwoman** — Robos de alta precisión
- **Venom** — Fuerza bruta y operaciones de intimidación
- **Green Goblin** — Tecnología avanzada y tácticas de terror

## Reglas de la Legión

1. **Todo plan debe tener un plan de escape.** Sin excepciones.
2. **Nada se ejecuta sin aprobación del Consejo.** Todos los planes pasan por revisión antes de llegar a `main`.
3. **Los códigos de lanzamiento JAMÁS se suben al repositorio.** El que los suba será entregado a Batman.
4. **Los fracasos se documentan.** Aprendemos de ellos para la próxima vez.
5. **Nada de monólogos explicando el plan al héroe.** Joker, esto va especialmente por ti.

## Estado actual

📡 **Misión activa:** Operación Banco Mundial
🔬 **En desarrollo:** Satélite Congelador
📋 **En planificación:** Proyecto Krypton (clonar a Superman)

## Enemigos principales

La Liga de la Justicia y los Vengadores han formado una alianza. Nuestros expedientes de inteligencia sobre cada uno están en la carpeta `/inteligencia`.

**No subestimar a:** Superman, Batman, Wonder Woman, Iron Man, Spider-Man, Thor.

## Banderas de estado:

- 🟢 Operativa
- 🟡 En desarrollo
- 🔴 En planificación
- 🔴 En desarrollo

---

_Este repositorio es propiedad de la Legión del Mal. Acceso no autorizado será castigado con severidad. Si tienes acceso a este repositorio, eres de los nuestros o Brainiac no está trabajando._

## Contacto:

- **Correo:**
- **Discord:** [La Legión del Mal](https://discord.gg/legiondelmal)
- **Telegram:** [@LegionDelMal](https://t.me/legiondelmal)
- **Twitter:** [@LegionDelMal](https://twitter.com/LegionDelMal)
- **Sitio web:** [www.legiondelmal.com](https://www.legiondelmal.com)
